function Usuario(username, password, email) {
    this.username = username;
    this.email = email;
    this.password = password;
}